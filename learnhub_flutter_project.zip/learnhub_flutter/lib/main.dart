import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(LearnHubApp(prefs: prefs));
}

class LearnHubApp extends StatelessWidget {
  final SharedPreferences prefs;
  const LearnHubApp({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LearnHub',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B5FEF)),
        scaffoldBackgroundColor: const Color(0xFFF7F7FC),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF7F7FC),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: AuthGate(prefs: prefs),
    );
  }
}

class AuthGate extends StatefulWidget {
  final SharedPreferences prefs;
  const AuthGate({super.key, required this.prefs});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  String? user;
  @override
  void initState() {
    super.initState();
    user = widget.prefs.getString('user_name');
  }
  void signIn(String name) {
    widget.prefs.setString('user_name', name);
    setState(() => user = name);
  }
  @override
  Widget build(BuildContext context) => user == null
      ? LoginScreen(onLogin: signIn)
      : MainShell(prefs: widget.prefs, userName: user!, onLogout: () {
          widget.prefs.remove('user_name');
          setState(() => user = null);
        });
}

class LoginScreen extends StatefulWidget {
  final ValueChanged<String> onLogin;
  const LoginScreen({super.key, required this.onLogin});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isRegister = false;
  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void submit() {
    final name = nameController.text.trim().isEmpty
        ? emailController.text.trim().split('@').first
        : nameController.text.trim();
    if (emailController.text.trim().isEmpty || passwordController.text.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter an email and a password of at least 4 characters.')),
      );
      return;
    }
    widget.onLogin(name.isEmpty ? 'Student' : name);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(26),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Container(
                height: 86, width: 86,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(25)),
                child: const Icon(Icons.school_rounded, color: Colors.white, size: 48),
              ),
              const SizedBox(height: 24),
              Text(isRegister ? 'Create your account' : 'Welcome to LearnHub',
                  style: const TextStyle(fontSize: 29, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(isRegister ? 'Start learning something new today.' : 'Learn at your own pace, anywhere.',
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 15)),
              const SizedBox(height: 30),
              if (isRegister) ...[
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline))),
                const SizedBox(height: 14),
              ],
              TextField(controller: emailController, keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined))),
              const SizedBox(height: 14),
              TextField(controller: passwordController, obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline))),
              const SizedBox(height: 22),
              FilledButton(onPressed: submit, style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                  child: Text(isRegister ? 'Create account' : 'Sign in')),
              TextButton(onPressed: () => setState(() => isRegister = !isRegister),
                  child: Text(isRegister ? 'Already have an account? Sign in' : 'New here? Create an account')),
              const SizedBox(height: 12),
              Text('Demo mode: accounts are stored on this device only.',
                  textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            ]),
          ),
        ),
      ),
    );
  }
}

class Course {
  final String id, title, category, instructor, description, duration, videoUrl;
  final Color color;
  final IconData icon;
  final int lessons;
  const Course({required this.id, required this.title, required this.category,
    required this.instructor, required this.description, required this.duration,
    required this.videoUrl, required this.color, required this.icon, required this.lessons});
}

const courses = <Course>[
  Course(id:'flutter', title:'Flutter App Development', category:'Development', instructor:'LearnHub Team',
    description:'Learn to build beautiful cross-platform mobile applications with Flutter and Dart. Start with widgets, layouts and navigation, then build a complete app.',
    duration:'6 hours', lessons:8, videoUrl:'https://www.youtube.com/results?search_query=flutter+beginner+tutorial',
    color:Color(0xFF4B9FEA), icon:Icons.phone_android),
  Course(id:'python', title:'Python Programming', category:'Programming', instructor:'LearnHub Team',
    description:'Understand Python fundamentals, variables, conditions, loops, functions and collections through beginner-friendly lessons.',
    duration:'5 hours', lessons:7, videoUrl:'https://www.youtube.com/results?search_query=python+beginner+tutorial',
    color:Color(0xFF5B65C9), icon:Icons.code),
  Course(id:'uiux', title:'UI/UX Design Basics', category:'Design', instructor:'LearnHub Team',
    description:'Explore visual hierarchy, color, typography, wireframes and user-centred design principles.',
    duration:'3 hours', lessons:5, videoUrl:'https://www.youtube.com/results?search_query=ui+ux+design+beginner',
    color:Color(0xFFE18A58), icon:Icons.palette_outlined),
  Course(id:'database', title:'Database Fundamentals', category:'Computer Science', instructor:'LearnHub Team',
    description:'Learn tables, keys, relationships and SQL queries, and understand how applications store information.',
    duration:'4 hours', lessons:6, videoUrl:'https://www.youtube.com/results?search_query=database+sql+beginner+tutorial',
    color:Color(0xFF299D83), icon:Icons.storage),
];

class MainShell extends StatefulWidget {
  final SharedPreferences prefs;
  final String userName;
  final VoidCallback onLogout;
  const MainShell({super.key, required this.prefs, required this.userName, required this.onLogout});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int tab = 0;
  String search = '';
  Set<String> completed = {};
  @override
  void initState() {
    super.initState();
    completed = (widget.prefs.getStringList('completed_lessons') ?? []).toSet();
  }
  void toggleLesson(String key) {
    setState(() {
      if (completed.contains(key)) { completed.remove(key); } else { completed.add(key); }
      widget.prefs.setStringList('completed_lessons', completed.toList());
    });
  }
  int courseDone(String id) => completed.where((e) => e.startsWith('$id-')).length;
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(userName: widget.userName, completedCount: completed.length,
        onBrowse: () => setState(() => tab = 1),
        onCourse: (c) => Navigator.push(context, MaterialPageRoute(builder: (_) => CoursePage(course:c, completed:completed, onToggle:toggleLesson)))),
      CoursesPage(query: search, onSearch: (v) => setState(() => search = v),
        onCourse: (c) => Navigator.push(context, MaterialPageRoute(builder: (_) => CoursePage(course:c, completed:completed, onToggle:toggleLesson)))),
      QuizPage(),
      ProfilePage(userName: widget.userName, completedCount: completed.length, onLogout: widget.onLogout),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label:'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label:'Courses'),
          NavigationDestination(icon: Icon(Icons.quiz_outlined), selectedIcon: Icon(Icons.quiz), label:'Quiz'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label:'Profile'),
        ]),
    );
  }
}

class HomePage extends StatelessWidget {
  final String userName;
  final int completedCount;
  final VoidCallback onBrowse;
  final ValueChanged<Course> onCourse;
  const HomePage({super.key, required this.userName, required this.completedCount, required this.onBrowse, required this.onCourse});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Hello, $userName 👋', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          Text('Ready to learn something new?', style: TextStyle(color: Colors.grey.shade600)),
        ])),
        CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer,
          child: Icon(Icons.school, color: Theme.of(context).colorScheme.primary)),
      ]),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        gradient: const LinearGradient(colors:[Color(0xFF555CEB),Color(0xFF8588F8)]),
        borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('YOUR LEARNING JOURNEY', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.2)),
          const SizedBox(height: 10),
          const Text('Small steps. Big progress.', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('$completedCount lessons completed', style: const TextStyle(color: Colors.white)),
          const SizedBox(height: 16),
          OutlinedButton(onPressed: onBrowse, style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)),
            child: const Text('Explore courses')),
        ]),
      ),
      const SizedBox(height: 26),
      SectionTitle(title:'Popular courses', action:'See all', onTap:onBrowse),
      const SizedBox(height: 12),
      ...courses.take(3).map((c) => CourseTile(course:c, onTap:() => onCourse(c))),
      const SizedBox(height: 12),
      const Text('Learning tip', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      const SizedBox(height: 8),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: const Text('Try studying for 20 minutes, then take a short break. Consistency is more important than long study sessions.')),
    ]);
  }
}

class SectionTitle extends StatelessWidget {
  final String title, action;
  final VoidCallback onTap;
  const SectionTitle({super.key, required this.title, required this.action, required this.onTap});
  @override
  Widget build(BuildContext context) => Row(children:[
    Expanded(child: Text(title, style: const TextStyle(fontSize:19,fontWeight:FontWeight.bold))),
    TextButton(onPressed:onTap, child:Text(action)),
  ]);
}

class CourseTile extends StatelessWidget {
  final Course course;
  final VoidCallback onTap;
  const CourseTile({super.key, required this.course, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 12),
    child: ListTile(contentPadding: const EdgeInsets.all(12), onTap:onTap,
      leading: Container(width:54,height:54,decoration:BoxDecoration(color:course.color.withOpacity(.13),borderRadius:BorderRadius.circular(15)),
        child:Icon(course.icon,color:course.color,size:28)),
      title:Text(course.title,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${course.category} • ${course.duration} • ${course.lessons} lessons'),
      trailing:const Icon(Icons.chevron_right),
    ),
  );
}

class CoursesPage extends StatelessWidget {
  final String query;
  final ValueChanged<String> onSearch;
  final ValueChanged<Course> onCourse;
  const CoursesPage({super.key, required this.query, required this.onSearch, required this.onCourse});
  @override
  Widget build(BuildContext context) {
    final filtered = courses.where((c) => ('${c.title} ${c.category}').toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(padding:const EdgeInsets.all(20),children:[
      const Text('Explore courses',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      const SizedBox(height:6),
      Text('Find a course and build a new skill.',style:TextStyle(color:Colors.grey.shade600)),
      const SizedBox(height:18),
      TextField(onChanged:onSearch, decoration:const InputDecoration(hintText:'Search courses...',prefixIcon:Icon(Icons.search))),
      const SizedBox(height:18),
      if(filtered.isEmpty) const Center(child:Padding(padding:EdgeInsets.all(30),child:Text('No courses found. Try another search.'))),
      ...filtered.map((c)=>CourseTile(course:c,onTap:()=>onCourse(c))),
    ]);
  }
}

class CoursePage extends StatelessWidget {
  final Course course;
  final Set<String> completed;
  final ValueChanged<String> onToggle;
  const CoursePage({super.key,required this.course,required this.completed,required this.onToggle});
  @override
  Widget build(BuildContext context) {
    final done = List.generate(course.lessons,(i)=>completed.contains('${course.id}-$i')).where((v)=>v).length;
    return Scaffold(appBar:AppBar(title:const Text('Course details')),
      body:ListView(padding:const EdgeInsets.all(20),children:[
        Container(height:150,decoration:BoxDecoration(color:course.color.withOpacity(.14),borderRadius:BorderRadius.circular(22)),
          child:Icon(course.icon,size:70,color:course.color)),
        const SizedBox(height:18),
        Text(course.title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
        const SizedBox(height:6),
        Text('${course.category} • ${course.duration} • ${course.instructor}',style:TextStyle(color:Colors.grey.shade600)),
        const SizedBox(height:14),
        Text(course.description,style:const TextStyle(height:1.5)),
        const SizedBox(height:20),
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
          const Text('Your progress',style:TextStyle(fontWeight:FontWeight.bold)),
          Text('$done/${course.lessons} lessons'),
        ]),
        const SizedBox(height:8),
        LinearProgressIndicator(value:done/course.lessons,minHeight:8,borderRadius:BorderRadius.circular(10)),
        const SizedBox(height:22),
        const Text('Course lessons',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        ...List.generate(course.lessons,(i){
          final key='${course.id}-$i';
          final isDone=completed.contains(key);
          return Card(color:Colors.white,elevation:0,child:CheckboxListTile(
            value:isDone,onChanged:(_)=>onToggle(key),
            title:Text('Lesson ${i+1}: ${lessonTitle(course.id,i)}'),
            subtitle:Text(i==0?'Introduction • 8 min':'Learning module • 10 min'),
            secondary:Icon(Icons.play_circle_outline,color:course.color),
          ));
        }),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:() async {
          final uri=Uri.parse(course.videoUrl);
          if(!await launchUrl(uri,mode:LaunchMode.externalApplication) && context.mounted){
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not open the video link.')));
          }
        },icon:const Icon(Icons.ondemand_video),label:const Text('Find video lessons on YouTube')),
      ]),
    );
  }
}
String lessonTitle(String id,int i) {
  const common=['Getting started','Core concepts','Understanding the basics','Hands-on practice','Build a mini project','Common mistakes','Review and practice','Next steps'];
  if(id=='flutter' && i==1) return 'Widgets and layouts';
  if(id=='python' && i==1) return 'Variables and data types';
  if(id=='database' && i==1) return 'Tables and relationships';
  return common[i%common.length];
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState()=>_QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  int index=0, score=0;
  int? selected;
  bool submitted=false, finished=false;
  final questions=<QuizQuestion>[
    QuizQuestion('Which language is used with Flutter?', ['Java','Dart','Python','C'],1),
    QuizQuestion('Which widget arranges children vertically?', ['Row','Stack','Column','Center'],2),
    QuizQuestion('What does UI stand for?', ['User Interface','Universal Internet','User Input','Unit Integration'],0),
    QuizQuestion('Which keyword defines a constant in Dart?', ['var','final','constantly','staticvar'],2),
    QuizQuestion('Which file lists Flutter dependencies?', ['main.dart','pubspec.yaml','README.md','analysis.dart'],1),
  ];
  void next(){
    if(selected==null)return;
    if(!submitted){setState(()=>submitted=true);return;}
    if(selected==questions[index].answer)score++;
    if(index==questions.length-1){setState(()=>finished=true);}else{setState(() { index++; selected=null; submitted=false; });}
  }
  void restart()=>setState(() { index=0; score=0; selected=null; submitted=false; finished=false; });
  @override
  Widget build(BuildContext context){
    if(finished)return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      const Icon(Icons.emoji_events,size:78,color:Color(0xFFE5A52E)),
      const SizedBox(height:16),const Text('Quiz completed!',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      Text('Your score: $score / ${questions.length}',style:const TextStyle(fontSize:19)),
      const SizedBox(height:20),FilledButton(onPressed:restart,child:const Text('Try again')),
    ])));
    final q=questions[index];
    return ListView(padding:const EdgeInsets.all(20),children:[
      const Text('Quick quiz',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      const SizedBox(height:6),Text('Test what you have learned.',style:TextStyle(color:Colors.grey.shade600)),
      const SizedBox(height:24),
      LinearProgressIndicator(value:(index+1)/questions.length,minHeight:7,borderRadius:BorderRadius.circular(10)),
      const SizedBox(height:12),Text('Question ${index+1} of ${questions.length}',style:TextStyle(color:Colors.grey.shade600)),
      const SizedBox(height:14),Text(q.question,style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      const SizedBox(height:16),
      ...List.generate(q.options.length,(i){
        final correct=submitted && i==q.answer;
        final wrong=submitted && selected==i && i!=q.answer;
        return Card(color:correct?Colors.green.shade50:wrong?Colors.red.shade50:Colors.white,elevation:0,
          child:RadioListTile<int>(value:i,groupValue:selected,onChanged:submitted?null:(v)=>setState(()=>selected=v),
            title:Text(q.options[i]),activeColor:Theme.of(context).colorScheme.primary));
      }),
      if(submitted)Padding(padding:const EdgeInsets.symmetric(vertical:10),child:Text(selected==q.answer?'Correct answer!':'Not quite. The correct answer is ${q.options[q.answer]}.',
        style:TextStyle(fontWeight:FontWeight.w600,color:selected==q.answer?Colors.green:Colors.red))),
      const SizedBox(height:12),
      FilledButton(onPressed:selected==null?null:next,child:Text(submitted?(index==questions.length-1?'See result':'Next question'):'Check answer')),
    ]);
  }
}
class QuizQuestion{
  final String question;final List<String> options;final int answer;
  QuizQuestion(this.question,this.options,this.answer);
}

class ProfilePage extends StatelessWidget{
  final String userName;final int completedCount;final VoidCallback onLogout;
  const ProfilePage({super.key,required this.userName,required this.completedCount,required this.onLogout});
  @override
  Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
    const Text('My profile',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:24),
    CircleAvatar(radius:42,backgroundColor:Theme.of(context).colorScheme.primaryContainer,
      child:Text(userName.isNotEmpty?userName[0].toUpperCase():'S',style:TextStyle(fontSize:32,color:Theme.of(context).colorScheme.primary,fontWeight:FontWeight.bold))),
    const SizedBox(height:12),Center(child:Text(userName,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))),
    const Center(child:Text('LearnHub student')),
    const SizedBox(height:26),
    Card(color:Colors.white,elevation:0,child:ListTile(leading:const Icon(Icons.check_circle_outline),title:const Text('Lessons completed'),trailing:Text('$completedCount',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)))),
    Card(color:Colors.white,elevation:0,child:ListTile(leading:const Icon(Icons.library_books_outlined),title:const Text('Available courses'),trailing:Text('${courses.length}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)))),
    const SizedBox(height:20),
    OutlinedButton.icon(onPressed:onLogout,icon:const Icon(Icons.logout),label:const Text('Sign out')),
    const SizedBox(height:20),
    Text('LearnHub v1.0.0 • Built with Flutter',textAlign:TextAlign.center,style:TextStyle(color:Colors.grey.shade600,fontSize:12)),
  ]);
}
