# LearnHub – Flutter Student Learning App

A beginner-friendly Student Learning Management System (LMS) built with Flutter and Dart.

## Features
- Demo sign-in / account creation screen
- Student dashboard
- Course catalogue with search
- Course details and lesson checklist
- Saved lesson completion progress (SharedPreferences)
- YouTube learning-resource links
- Interactive multiple-choice quiz with score
- Student profile and sign-out
- Material 3 responsive UI

## Tech stack
- Flutter / Dart
- Material 3
- `shared_preferences` for on-device progress and demo sign-in
- `url_launcher` for opening video-resource searches

## Run locally
1. Install Flutter SDK and Android Studio (or another device emulator).
2. Open this folder in VS Code.
3. In the terminal, run:

```bash
flutter doctor
flutter pub get
flutter run
```

## Demo account
This is a learning/demo app. Enter any email address and a password of at least 4 characters. You can optionally enter a name during account creation.

**Important:** Authentication is simulated and stored locally. It is not secure production authentication. Do not use real passwords. For a production deployment, connect Firebase Authentication and Cloud Firestore, add proper authorization rules, and replace the demo login flow.

## GitHub upload
Create a public repository named `learnhub-flutter`, then run these commands from this project folder:

```bash
git init
git add .
git commit -m "Initial LearnHub Flutter LMS"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/learnhub-flutter.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## Suggested next improvements
- Replace demo login with Firebase Authentication.
- Store courses, users and quiz results in Cloud Firestore.
- Add real video playback and instructor-uploaded lessons.
- Add unit/widget tests and app screenshots.
